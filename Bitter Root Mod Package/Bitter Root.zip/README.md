# Mildly Helpful bits#
It's p bitter y'all. You only need the parts in "The Mod Bits" folder, everything else was required to upload the mod ;-;
# Decidedly Less Helpful bits
Additively stacks, after all other health items just like its original incarnation.

Excessive use of bitter root can replace skill where needed.
